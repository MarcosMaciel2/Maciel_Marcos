require('rootpath')();
const express = require('express');
const app = express();

const DiaDb = require("model/diasM.js");
const cont_security = require("controller/securityC.js");


app.get("/", cont_security.verificar,(req, res) => { //GET
    DiaDb.getR((err, result) => {
        if (err) {
            res.status(err.status).send(err);
        } else {
            res.json(result);
        }
    });
});

app.get('/:dia', cont_security.verificar,(req, res) => { // GET ID By dia
    DiaDb.getID(req.params.dia, (err, result) => {
        if (err) {
            res.status(err.status).send(err);
        } else {
            res.json(result);
        }
    });
});

module.exports = app;