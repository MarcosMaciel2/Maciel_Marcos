require('rootpath')();
const express = require('express');
const app = express();

const codigo_estudioDb = require("model/codigo_estudioM.js");
const cont_security = require("controller/securityC.js");

app.get("/", cont_security.verificar,(req, res) => { //GET
    codigo_estudioDb.getCE((err, result) => {
            if (err) {
                res.status(err.status).send(err);
            } else {
                res.json(result);
            }
        });
});

app.post('/', cont_security.verificar,(req, res) => { //POST
    let codigo_estudio = req.body;
    codigo_estudioDb.create(codigo_estudio, (err, result) => {
        if(err){
            res.status(err.status).send(err);
        }else{
            res.json(result);
        }
    })
});

app.put('/:codigo', cont_security.verificar,(req, res) => { //PUT
    let codigo = req.params.codigo;
    let codigo_estudio = req.body;
    codigo_estudioDb.update(codigo, codigo_estudio, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});

app.delete('/:codigo', cont_security.verificar,(req, res) => { // DELETE
    codigo_estudioDb.delete(req.params.codigo, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});


module.exports = app;