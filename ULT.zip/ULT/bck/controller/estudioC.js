require('rootpath')();
const express = require('express');
const app = express();

const estudioDb = require("model/estudioM.js");
const cont_security = require("controller/securityC.js");

app.get("/", cont_security.verificar,(req, res) => { //GET
    estudioDb.getE((err, result) => {
            if (err) {
                res.status(err.status).send(err);
            } else {
                res.json(result);
            }
        });
});

app.post('/', cont_security.verificar,(req, res) => { //POST
    let estudio = req.body;
    estudioDb.create(estudio, (err, result) => {
        if(err){
            res.status(err.status).send(err);
        }else{
            res.json(result);
        }
    })
});

app.put('/:id_estudio', cont_security.verificar,(req, res) => { //PUT
    let id_estudio = req.params.id_estudio;
    let estudio = req.body;
    estudioDb.update(id_estudio, estudio, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});

app.delete('/:id_estudio', cont_security.verificar,(req, res) => { // DELETE
    estudioDb.delete(req.params.id_estudio, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});


module.exports = app;