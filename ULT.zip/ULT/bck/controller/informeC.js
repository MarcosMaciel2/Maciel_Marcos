require('rootpath')();
const express = require('express');
const app = express();

const informeDb = require("model/informeM.js");
const cont_security = require("controller/securityC.js");

app.get("/", cont_security.verificar,(req, res) => { //GET
    informeDb.getI((err, result) => {
            if (err) {
                res.status(err.status).send(err);
            } else {
                res.json(result);
            }
        });
});

app.post('/', cont_security.verificar,(req, res) => { //POST
    let informe = req.body;
    informeDb.create(informe, (err, result) => {
        if(err){
            res.status(err.status).send(err);
        }else{
            res.json(result);
        }
    })
});

app.put('/:id_informe', cont_security.verificar,(req, res) => { //PUT
    let id_informe = req.params.id_informe;
    let informe = req.body;
    informeDb.update(id_informe, informe, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});

app.delete('/:id_informe', cont_security.verificar,(req, res) => { // DELETE
    informeDb.delete(req.params.id_informe, (err, result) => {
        if (err) {
            res.status(err.status).json(err);
        } else {
            res.json(result);
        }
    });
});


module.exports = app;