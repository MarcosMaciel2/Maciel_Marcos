require('rootpath')();
const express = require('express');
const app = express();

const registrarse = require("../model/registrarseM");
const cont_security = require("controller/securityC.js");


app.post('/', (req, res) => { //POST
    let usuario = req.body;
    registrarse.create(usuario, (err, result) => {
        if (err) {
            res.status(err.status).send(err);
        } else {
            res.json(result);
        }
    })
});

module.exports = app;