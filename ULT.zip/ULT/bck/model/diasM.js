require('rootpath')();
const dias_db = {};

const mysql = require('mysql');
const config = require("config.json");
const funcionesAuxiliares = require("../funcionesAuxiliares");


const connection = mysql.createConnection(config.database);
connection.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("La tabla 'dia', se encuentra disponible.")
    }
});

dias_db.getR = function (funCallback) { //GET
    try {
        let consulta = 'SELECT * FROM dias order by id_dias asc';
        connection.query(consulta, function (err, rows) {
            if (err) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "dias", "id_dias");
            } else {
                funCallback(undefined, rows);
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "dias", "id_dias");
    }
};



dias_db.getID = function (dias, funCallback) { // GET ID BY dias
    try {
        const expectedTypes = ['password']; //Parche
        let params = [dias];
        funcionesAuxiliares.validar(params, expectedTypes);

        let consulta = "SELECT id_dias FROM dias WHERE dias = ?";

        connection.query(consulta, params, (err, result) => {
            if (err || result.affectedRows === 0) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "doctor", "id_doctor");
            } else {
                funCallback(undefined, result);
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "doctor", "id_doctor");
    }
};


module.exports = dias_db;