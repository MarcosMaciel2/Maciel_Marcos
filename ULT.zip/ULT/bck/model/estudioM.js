require('rootpath')();
const estudio_db = {};

const mysql = require('mysql');
const config = require("config.json");
const funcionesAuxiliares = require("../funcionesAuxiliares");

//Conexión a la base de datos.
const connection = mysql.createConnection(config.database);
connection.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("La tabla 'estudio', se encuentra disponible.")
    }
});

estudio_db.getE = function (funCallback) { //GET
    try {
        let consulta = 'SELECT * FROM estudio';
        connection.query(consulta, function (err, rows) {
            if (err) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "estudio", "id_estudio");
            } else {
                funCallback(undefined, rows);
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "estudio", "id_estudio");
    }
};

estudio_db.create = function (estudio, funCallback) { //POST
    try {
        const expectedTypes = ['object', 'text', 'text', 'text'];
        let params = [estudio.fecha_hora, estudio.valores_referencia, estudio.codigo, estudio.id_doctor];
        funcionesAuxiliares.validar(params, expectedTypes);

        let consulta = 'INSERT INTO estudio (fecha_hora, valores_referencia, codigo, id_doctor) VALUES (?,?,?,?)';

        connection.query(consulta, params, (err, result) => {
            if (err) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "estudio", "id_estudio");
            } else {
                funCallback(undefined, {
                    message: `Se creó el estudio ${estudio.codigo_estudio}`,
                    detail: result
                });
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "estudio", "id_estudio");
    }
};

estudio_db.update = function (id_estudio, estudio, funCallback) { //PUT
    try {
        const expectedTypes = ['object', 'text', 'text', 'number', 'number'];
        let params = [estudio.fecha_hora, estudio.valores_referencia, estudio.codigo, estudio.id_doctor, id_estudio];
        funcionesAuxiliares.validar(params, expectedTypes);

        let consulta = 'UPDATE estudio SET  fecha_hora = ?, valores_referencia = ?, codigo = ?, id_doctor = ? WHERE id_estudio = ?';

        connection.query(consulta, params, function (err, result) {
            if (err || result.affectedRows == 0) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "estudio", "id_estudio");
            } else {
                funCallback(undefined, {
                    message: `Se actualizó el estudio ${estudio.fecha_hora}`,
                    detail: result
                });
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "estudio", "id_estudio");
    }
};

estudio_db.delete = function (id_estudio, funCallback) { // DELETE
    try {
        const expectedTypes = ['number'];
        let params = [id_estudio];
        funcionesAuxiliares.validar(params, expectedTypes);

        let consulta = "DELETE FROM estudio WHERE id_estudio = ?";

        connection.query(consulta, params, (err, result) => {
            if (err || result.affectedRows === 0) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "estudio", "id_estudio");
            } else {
                funCallback(undefined, {
                    mensaje: `El estudio N° ${id_estudio} fue eliminado correctamente`,
                    detalle: result
                });
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "estudio", "id_estudio");
    }
};


module.exports = estudio_db;