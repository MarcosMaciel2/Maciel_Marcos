require('rootpath')();
const registrarse = {};
const mysql = require('mysql');
const config = require("config.json");
const bcrypt = require('bcrypt');
const funcionesAuxiliares = require("../funcionesAuxiliares");

const connection = mysql.createConnection(config.database);
connection.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("La tabla 'registrarse', se encuentra disponible.")
    }
});

registrarse.create = function (usuario, funCallback) { //POST
    try {
        
        let claveCifrada = bcrypt.hashSync(usuario.password, 10);
        const expectedTypes = ['text', 'text', 'number', 'object', 'email', 'number', 'text', 'number'];
        let params = [usuario.nombre, usuario.apellido, usuario.dni, usuario.fecha_nacimiento, usuario.email, usuario.genero, claveCifrada];  // MARCOS hice volar el rol. Solo se puede registrar como paciente
        funcionesAuxiliares.validar(params, expectedTypes);

        let consulta = 'INSERT INTO usuario (nombre, apellido, dni, fecha_nacimiento, email, genero, password, rol) VALUES (?,?,?,?,?,?,?,3)';

        connection.query(consulta, params, (err, result) => {
            if (err) {
                funcionesAuxiliares.errorGlobal(funCallback, err, result, "usuario", "email");
            } else {
                funCallback(undefined, {
                    message: `El email ${usuario.email}, se registró exitosamente`,
                    detail: result
                });
            }
        });
    } catch (err) {
        funcionesAuxiliares.errorGlobal(funCallback, err, null, "usuario", "email");
    }
};

module.exports = registrarse;