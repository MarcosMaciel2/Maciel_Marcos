import React, { Component } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import 'react-toastify/dist/ReactToastify.css';


export class Estudioxd extends Component {
    constructor(props) {
        super(props);

        this.state = {
            estudios: []
        }; 
        this.closeModal = this.closeModal.bind(this)
        this.showModal = this.showModal.bind(this)       
    }
    closeModal() {
        this.setState({
            modal: false,
            idToDelete: null
        })
    }

    showModal(codigo) {
        this.setState({
            modal: true,
            idToDelete: codigo
        })
    }

    handleSubmit = (event) => {
        event.preventDefault();



        const estudiosx = {
            fecha_hora: this.state.fecha_hora,
            valores_referencia: this.state.valores_referencia,
            codigo : this.state.codigo,
            id_usuarioP : this.state.id_usuarioP,
        };
        const parametros = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'token': localStorage.getItem('token')
            },
            body: JSON.stringify(estudiosx),
            
        };

        fetch(`http://localhost:8080/api/estudio`, parametros)
            .then((res) => {
                return res.json().then((body) => {debugger
                    return {
                        status: res.status,
                        ok: res.ok,
                        headers: res.headers,
                        body: body,
                    };
                });
            })
            .then((result) => {
                if (result.ok) {
                    toast.success(result.body.message, {
                        position: 'bottom-center',
                        autoClose: 500,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: 'light',
                    });
                    // this.props.navigate("/usuario")    Podria ir a usuario o recargar la pag
                    //setTimeout(() => {
                    //window.location.reload() }, 500); // O podria poner un reload y IZI
                    this.handleClickTodos();
                } else {
                    toast.error(result.body.message, {
                        position: 'bottom-center',
                        autoClose: 500,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: 'light',
                    });
                }
            })
            .catch((error) => {
                console.error('Fetch error:', error);
            });
    };
    

    handleChange = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    };

    handleClickTodos = () => {

            let parametros = {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'token': localStorage.getItem('token')
                }
            }
            const url = `http://localhost:8080/api/estudio`

            fetch(url, parametros)
                .then(res => {
                    return res.json()
                        .then(body => (
                            {
                                status: res.status,
                                ok: res.ok,
                                headers: res.headers,
                                body: body
                            }
                        )
                        ).then(
                            result => {
                                if (result.ok) {
                                    this.setState({
                                        estudios: result.body
                                    });                                    
                                }
                                else {
                                    toast.error(result.body.message, {
                                        position: "bottom-center",
                                        autoClose: 500,
                                        hideProgressBar: false,
                                        closeOnClick: true,
                                        pauseOnHover: true,
                                        draggable: true,
                                        progress: undefined,
                                        theme: "light",
                                    });
                                }
                            });
                })
                .catch((error) => {
                    console.log('Error:', error);
                }
                );
        };


        handleClickDelete() {

            if (this.state.idToDelete) {
                let parametros = {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'token': localStorage.getItem('token')
                    }
                }
                const url = `http://localhost:8080/api/estudio/${this.state.idToDelete}`
    
                fetch(url, parametros)
                    .then(res => {
                        return res.json()
                            .then(body => (
                                {
                                    status: res.status,
                                    ok: res.ok,
                                    headers: res.headers,
                                    body: body
                                }
                            )
                            ).then(
                                result => {
                                    if (result.ok) {
                                        toast.success(result.body.message, {
                                            position: "bottom-center",
                                            autoClose: 500,
                                            hideProgressBar: false,
                                            closeOnClick: true,
                                            pauseOnHover: true,
                                            draggable: true,
                                            progress: undefined,
                                            theme: "light",
                                        });
                                        this.closeModal();
                                        this.handleClickTodos();
                                    } else {
                                        toast.error(result.body.message, {
                                            position: "bottom-center",
                                            autoClose: 500,
                                            hideProgressBar: false,
                                            closeOnClick: true,
                                            pauseOnHover: true,
                                            draggable: true,
                                            progress: undefined,
                                            theme: "light",
                                        });
                                    }
                                });
                    })
                    .catch((error) => {
                       console.log('Error:', error);
                    }
                    );
            }
        };

    render() {
        const filas = this.state.estudios.map((estudios, index) => {
            return (
                <>
                <tr key={index}>
                    <td>{estudios.id_estudio}</td>
                    <td>{estudios.fecha_hora}</td>
                    <td>{estudios.valores_referencia}</td>
                    <td>{estudios.codigo}</td>
                    <td>{estudios.id_usuarioP}</td>


                    <td>
                        <Link to={`/estudios/edit/${estudios.id_estudio}`} className="btn btn-secondary">
                            <span className="material-symbols-outlined">
                                edit
                            </span></Link>
                        <button className="btn btn-danger" onClick={() => this.showModal(estudios.id_estudio)} >
                            <span className="material-symbols-outlined">
                                delete
                            </span></button>
                    </td>
                </tr>
                
                </>
            )
        })
        
        return (
            <>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <h1>Crear Estudio</h1>
                        <form onSubmit={this.handleSubmit}>
                            <div className="form-floating">
                                <input
                                    type="date"
                                    className="form-control"
                                    id='floatingfecha_hora'
                                    value={this.state.fecha_hora}
                                    name='fecha_hora'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingfecha_hora">fecha_hora</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingvalores_referencia'
                                    value={this.state.valores_referencia}
                                    name='valores_referencia'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingvalores_referencia">valores_referencia</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingcodigo'
                                    value={this.state.codigo}
                                    name='codigo'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingcodigo">codigo</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingid_usuarioP'
                                    value={this.state.id_usuarioP}
                                    name='id_usuarioP'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingid_usuarioP">id_usuarioP</label>
                            </div>
                            <br/>
                            <input
                                className='btn btn-outline-primary'
                                type='submit'
                                value='Crear'
                            />
                        </form>
                        <br />
                        <Link to={`/estudios/`} className="btn btn-outline-danger" onClick={this.handleClickTodos}>Get All Estudios</Link>
                        <br />
                        <div>
                            <table className='table table-striped'>
                                <thead>
                                    <tr>
                                        <th>id_estudio</th>
                                        <th>fecha_hora</th>
                                        <th>valores_referencia</th>
                                        <th>codigo</th>
                                        <th>id_usuarioP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filas}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <Modal show={this.state.modal} onHide={this.closeModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Confirmar</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>¿Está seguro que desea eliminar este usuario?</Modal.Body>
                    <Modal.Footer>
                        <Button variant="danger" onClick={() => this.handleClickDelete()}>
                            Eliminar
                        </Button>
                        <Button variant="primary" onClick={this.closeModal}>
                            Cancelar
                        </Button>
                    </Modal.Footer>
                </Modal>
            </>
        );
    }
}

export default Estudio


export function Estudio() {
    const p = useParams();
    const navigate = useNavigate();
    return (
        <>
            <Estudioxd navigate={navigate} params={p} />
        </>
    );
}