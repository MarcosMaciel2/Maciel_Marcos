import React from 'react';

export class Home extends React.Component {

    render() {
        return <>
            <h1>Bienvenido al sitio web del Consultorio Nosiglia </h1>
        </>

    }
}