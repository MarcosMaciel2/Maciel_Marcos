import React, { Component } from 'react'

export class Usuario_Historia_Clinica extends Component {
    render() {
        return (
            <div>Una lista organizada cronólogicamente con los turnos concretados e informes de los estudios realizados al paciente.</div>
        )
    }
}

export default Usuario_Historia_Clinica