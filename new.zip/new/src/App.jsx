/* eslint-disable react/jsx-pascal-case */
import { Navigate, Route, Routes } from 'react-router-dom';
import { Home } from './Home';
import './index.css';
import Login from './Login';
import Menu from './Menu';
import Usuario from './model/usuario';
import TestUsuarios from './model/TestUsuarios';
import Usuario_Edit from './model/Usuario_Edit';
import Usuario_Turno from './model/Usuario_Turno';
import { ToastContainer } from 'react-toastify';
import Usuario_Historia_Clinica from './model/Usuario_Historia_Clinica';
import Doctores from './Doctores';
import Turnos from './Turnos';
import Registrarse from './Registrarse';
import { CodEstudio } from './CodEstudio';
import { CodEstudioEdit } from './CodEstudioEdit';
import Paciente from './Paciente';
import Historial from './Historial';
import Estudio from './Estudio';
import Informe from './Informe';
import HistorialEdit from './HistorialEdit';
import InformeEdit from './InformeEdit';
import EstudioEdit from './EstudioEdit';
import PacienteEdit from './PacienteEdit';
import DoctoresEdit from './DoctoresEdit';
import jwt_decode from 'jwt-decode';



function App() {
  const token = localStorage.getItem('token');
  let userRole = null;

if (token) {
  const decodedToken = jwt_decode(token);
  userRole = decodedToken.rol;
}


  return (
    <>
      <Menu />
      <ToastContainer />
      <div className='container'>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/TestUsuarios" element={<TestUsuarios />} />
          <Route path="/login" element={userRole === 1 || userRole === 2 || userRole === 3? <Navigate to="/" /> : <Login />} />
          <Route path="/registrarse" element={userRole === 1 || userRole === 2 || userRole === 3? <Navigate to="/" /> : <Registrarse />} />

          <Route path="/usuario" element={userRole === 1 || userRole === 2 ? <Usuario /> : <Navigate to="/" />}/>
          <Route path="/usuario/edit" element={userRole === 1  ? <Usuario_Edit /> : <Navigate to="/" />} />
          <Route path="/usuario/edit/:id_usuario" element={userRole === 1 ? <Usuario_Edit /> : <Navigate to="/" />}/>
          <Route path="/usuario/turno/:id_usuario" element={userRole === 1 || userRole === 2  ? <Usuario_Turno /> : <Navigate to="/" />} />
          <Route path="/usuario/historia_clinica/:id_usuario" element={userRole === 1 || userRole === 2 ? <Usuario_Historia_Clinica /> : <Navigate to="/" />} />
          
          <Route path="/doctores" element={userRole === 1 || userRole === 2 ? <Doctores /> : <Navigate to="/" />} />
          <Route path="/doctores/edit/:id_doctor" element={userRole === 1 || userRole === 2  ? <DoctoresEdit /> : <Navigate to="/" />} />
          
          <Route path="/paciente" element={userRole === 1 || userRole === 2 || userRole === 3? <Paciente />  : <Navigate to="/" />} />
          <Route path="/paciente/edit/:id_paciente" element={userRole === 1 || userRole === 3 ? <PacienteEdit /> : <Navigate to="/" />} />
          
          <Route path="/turnos" element={userRole === 1 || userRole === 2 || userRole === 3? <Turnos /> : <Navigate to="/" />} />
          <Route path="/turnos/:id_usuario" element={userRole === 1 || userRole === 2 || userRole === 3? <Turnos />  : <Navigate to="/" />} />
          
          <Route path="/codigo_estudio" element={userRole === 1 ? <CodEstudio /> : <Navigate to="/" />} />
          <Route path="/codigo_estudio/edit/:codigo" element={userRole === 1 ? <CodEstudioEdit /> : <Navigate to="/" />} />
          
          <Route path="/estudios" element={userRole === 1 || userRole === 2 ? <Estudio /> : <Navigate to="/" />} />
          <Route path="/estudios/edit/:id_estudio" element={userRole === 1 || userRole === 2 ? <EstudioEdit /> : <Navigate to="/" />} />
          
          <Route path="/informe" element={userRole === 1 || userRole === 2 || userRole === 3? <Informe />   : <Navigate to="/" />} />
          <Route path="/informe/edit/:id_informe" element={userRole === 1 || userRole === 2 ? <InformeEdit /> : <Navigate to="/" />} />
          
          <Route path="/historia_clinica" element={userRole === 1 || userRole === 2 || userRole === 3? <Historial />  : <Navigate to="/" />} />
          <Route path="/historia_clinica/edit/:id_historia_clinica" element={userRole === 1 || userRole === 2 ? <HistorialEdit /> : <Navigate to="/" />} />
        </Routes>
      </div>
    </>
  );
}


export default App;