import React, { Component } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import 'react-toastify/dist/ReactToastify.css';


export class Pacientexd extends Component {
    constructor(props) {
        super(props);

        this.state = {
            paciente: []
        };        
        this.closeModal = this.closeModal.bind(this)
        this.showModal = this.showModal.bind(this)
    }
    closeModal() {
        this.setState({
            modal: false,
            idToDelete: null
        })
    }

    showModal(codigo) {
        this.setState({
            modal: true,
            idToDelete: codigo
        })
    }

    handleSubmit = (event) => {
        event.preventDefault();

        const pacientex = {
            obra_social: this.state.obra_social,
            pais: this.state.pais,
            provincia: this.state.provincia,
            localidad: this.state.localidad,
            direccion: this.state.direccion,
            id_usuario: this.state.id_usuario,
            id_rol: this.state.id_rol,
        };
        const parametros = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'token': localStorage.getItem('token')
            },
            body: JSON.stringify(pacientex),
            
        };

        fetch(`http://localhost:8080/api/paciente`, parametros)
            .then((res) => {
                return res.json().then((body) => {debugger
                    return {
                        status: res.status,
                        ok: res.ok,
                        headers: res.headers,
                        body: body,
                    };
                });
            })
            .then((result) => {
                if (result.ok) {
                    toast.success(result.body.message, {
                        position: 'bottom-center',
                        autoClose: 500,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: 'light',
                    });
                    // this.props.navigate("/usuario")    Podria ir a usuario o recargar la pag
                    //setTimeout(() => {
                    //window.location.reload() }, 500); // O podria poner un reload y IZI
                    this.handleClickTodos();
                } else {
                    toast.error(result.body.message, {
                        position: 'bottom-center',
                        autoClose: 500,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: 'light',
                    });
                }
            })
            .catch((error) => {
                console.error('Fetch error:', error);
            });
    };
    

    handleChange = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    };

    handleClickTodos = () => {
            let parametros = {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'token': localStorage.getItem('token')
                }
            }
            const url = `http://localhost:8080/api/paciente/`

            fetch(url, parametros)
                .then(res => {
                    return res.json()
                        .then(body => (
                            {
                                status: res.status,
                                ok: res.ok,
                                headers: res.headers,
                                body: body
                            }
                        )
                        ).then(
                            result => {
                                if (result.ok) {
                                    this.setState({
                                            paciente: result.body
                                    });                                    
                                }
                                else {
                                    toast.error(result.body.message, {
                                        position: "bottom-center",
                                        autoClose: 500,
                                        hideProgressBar: false,
                                        closeOnClick: true,
                                        pauseOnHover: true,
                                        draggable: true,
                                        progress: undefined,
                                        theme: "light",
                                    });
                                }
                            });
                })
                .catch((error) => {
                    console.log('Error:', error);
                }
                );
        };


        handleClickDelete() {

            if (this.state.idToDelete) {
                let parametros = {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'token': localStorage.getItem('token')
                    }
                }
                const url = `http://localhost:8080/api/paciente/${this.state.idToDelete}`
    
                fetch(url, parametros)
                    .then(res => {
                        return res.json()
                            .then(body => (
                                {
                                    status: res.status,
                                    ok: res.ok,
                                    headers: res.headers,
                                    body: body
                                }
                            )
                            ).then(
                                result => {
                                    if (result.ok) {
                                        toast.success(result.body.message, {
                                            position: "bottom-center",
                                            autoClose: 500,
                                            hideProgressBar: false,
                                            closeOnClick: true,
                                            pauseOnHover: true,
                                            draggable: true,
                                            progress: undefined,
                                            theme: "light",
                                        });
                                        this.closeModal();
                                        this.handleClickTodos();
                                    } else {
                                        toast.error(result.body.message, {
                                            position: "bottom-center",
                                            autoClose: 500,
                                            hideProgressBar: false,
                                            closeOnClick: true,
                                            pauseOnHover: true,
                                            draggable: true,
                                            progress: undefined,
                                            theme: "light",
                                        });
                                    }
                                });
                    })
                    .catch((error) => {
                    console.log('Error:', error);
                    }
                    );
            }
        };

    render() {
        const filas = this.state.paciente.map((paciente, index) => {
            return (
                <>
                <tr key={index}>
                    <td>{paciente.id_paciente}</td>
                    <td>{paciente.obra_social}</td>
                    <td>{paciente.pais}</td>
                    <td>{paciente.provincia}</td>
                    <td>{paciente.localidad}</td>
                    <td>{paciente.direccion}</td>
                    <td>{paciente.id_usuario}</td>
                    <td>{paciente.id_rol}</td>

                    <td>
                        <Link to={`/paciente/edit/${paciente.id_paciente}`} className="btn btn-secondary">
                            <span className="material-symbols-outlined">
                                edit
                            </span></Link>
                        <button className="btn btn-danger" onClick={() => this.showModal(paciente.id_paciente)} >
                            <span className="material-symbols-outlined">
                                delete
                            </span></button>
                    </td>
                </tr>
                </>
            )
        })
        
        return (
            <>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <h1>Crear Paciente</h1>
                        <form onSubmit={this.handleSubmit}>
                        <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingobra_social'
                                    value={this.state.obra_social}
                                    name='obra_social'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingobra_social">Ingresar tu Obra Social</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingpais'
                                    value={this.state.pais}
                                    name='pais'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingpais">pais</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingprovincia'
                                    value={this.state.provincia}
                                    name='provincia'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingprovincia">provincia</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatinglocalidad'
                                    value={this.state.localidad}
                                    name='localidad'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatinglocalidad">localidad</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingdireccion'
                                    value={this.state.direccion}
                                    name='direccion'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingdireccion">direccion</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingid_usuario'
                                    value={this.state.id_usuario}
                                    name='id_usuario'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingid_usuario">id_usuario</label>
                            </div>
                            <br/>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingid_rol'
                                    value={this.state.id_rol}
                                    name='id_rol'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingid_rol">id_rol</label>
                            </div>
                            <br/>
                            <input
                                className='btn btn-outline-primary'
                                type='submit'
                                value='Crear'
                            />
                        </form>
                        <br />
                        <Link to={`/paciente/`} className="btn btn-outline-danger" onClick={this.handleClickTodos}>Get All Obras</Link>
                        <br />
                        <div>
                            <table className='table table-striped'>
                                <thead>
                                    <tr>
                                        <th>id_paciente</th>
                                        <th>obra_social</th>
                                        <th>pais</th>
                                        <th>provincia</th>
                                        <th>localidad</th>
                                        <th>direccion</th>
                                        <th>id_usuario</th>
                                        <th>id_rol</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filas}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <Modal show={this.state.modal} onHide={this.closeModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Confirmar</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>¿Está seguro que desea eliminar este usuario?</Modal.Body>
                    <Modal.Footer>
                        <Button variant="danger" onClick={() => this.handleClickDelete()}>
                            Eliminar
                        </Button>
                        <Button variant="primary" onClick={this.closeModal}>
                            Cancelar
                        </Button>
                    </Modal.Footer>
                </Modal>
            </>
        );
    }
}

export default Paciente


export function Paciente() {
    const p = useParams();
    const navigate = useNavigate();
    return (
        <>
            <Pacientexd navigate={navigate} params={p} />
        </>
    );
}