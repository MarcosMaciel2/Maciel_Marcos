import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react';
import jwt_decode from 'jwt-decode';


function Menu() {
    const navigate = useNavigate();

    const [token, setToken] = useState("");

    useEffect(() => {
        const t = localStorage.getItem('token');
        if (t !== token) {
            setToken(t);
        }
    });

    function verificarTokenCaducado(token) {    
        const decodedToken = jwt_decode(token);
        const expirationTime = decodedToken.exp * 1000;
        const currentTime = Date.now();
        return currentTime >= expirationTime;
    }


    const jwtToken = localStorage.getItem('token');  
    if (jwtToken) {
        if (verificarTokenCaducado(jwtToken)) {
            localStorage.removeItem('token');
            setToken("");
            navigate("/");
            window.location.reload();
        }
    }


    function logout() {
        localStorage.removeItem('token');
        window.location.reload();
        setToken("");
        navigate("/");
    }

    if (token !== "" && token !== null) {
        var decoded = jwt_decode(localStorage.getItem('token'))
        var rol = decoded.rol
        if (rol === 3) {
            rol = "Paciente"
        } else if (rol === 2) {
            rol = "Doctor"
        } else if (rol === 1) {
        rol = "ADMIN";}


        return <>
            <nav className="navbar navbar-expand-lg bg-body-tertiary">
                <div className="container-fluid">
                    <Link to="/" className='nav-link'>Home</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        {rol === "ADMIN"&& (<>
                            <li className="nav-item">
                                <Link to="usuario" className='nav-link'>Usuarios</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="doctores" className='nav-link'>Doctores</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="turnos" className='nav-link'>Turnos</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="codigo_estudio" className='nav-link'>Cod de Estudios</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="paciente" className='nav-link'>Paciente</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="historia_clinica" className='nav-link'>Historias Clinicas</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="estudios" className='nav-link'>Estudios</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="informe" className='nav-link'>Informe</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="TestUsuarios" className='nav-link'>TestUsuarios</Link>
                            </li>
                            <li className="nav-item-MISDATOS">
                            {`Bienvenid@! U: ${decoded.id_usuario} ${decoded.nombre} ROL: ${rol}`}
                            </li>
                            <li className="nav-item-btn">
                                <button className='btn' onClick={() => logout()}>
                                    <span className="material-symbols-outlined">
                                        logout
                                    </span>
                                </button>
                            </li></>)}
                            {rol === "Doctor"&& (<>
                                <li className="nav-item">
                                <Link to="usuario" className='nav-link'>Usuarios</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="doctores" className='nav-link'>Doctores</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="turnos" className='nav-link'>Turnos</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="historia_clinica" className='nav-link'>Historias Clinicas</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="estudios" className='nav-link'>Estudios</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="informe" className='nav-link'>Informe</Link>
                            </li>
                            <li className="nav-item-MISDATOS">
                            {`Bienvenid@! U: ${decoded.id_usuario} ${decoded.nombre} ROL: ${rol}`}
                            </li>
                            <li className="nav-item-btn">
                                <button className='btn' onClick={() => logout()}>
                                    <span className="material-symbols-outlined">
                                        logout
                                    </span>
                                </button>
                            </li>
                            </>)}
                            {rol === "Paciente"&& (<>
                                <li className="nav-item">
                                <Link to="turnos" className='nav-link'>Turnos</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="paciente" className='nav-link'>Paciente</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="informe" className='nav-link'>Informe</Link>
                            </li>
                            <li className="nav-item-MISDATOS">
                            {`Bienvenid@! U: ${decoded.id_usuario} ${decoded.nombre} ROL: ${rol}`}
                            </li>
                            <li className="nav-item-btn">
                                <button className='btn' onClick={() => logout()}>
                                    <span className="material-symbols-outlined">
                                        logout
                                    </span>
                                </button>
                            </li>
                            </>)}
                        </ul>
                    </div>
                </div>
            </nav>
        </>
    } else {
        return <>
            <nav className="navbar navbar-expand-lg bg-body-tertiary">
                <div className="container-fluid">
                    <Link to="/" className='nav-link'>Home</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link to="/login" className='nav-link'>Login</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/registrarse" className='nav-link'>Registrarse</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </>
    }
}

export default Menu;