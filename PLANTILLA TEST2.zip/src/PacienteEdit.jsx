import React, { Component } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export class PacienteE extends Component {
    constructor(props) {
        super(props);

        this.state = {
            id_paciente: '',
            obra_social: '',
            pais: '',
            provincia: '',
            localidad: '',
            direccion: '',
            id_usuario: '',
            id_rol: '',
        };
    }
    handleSubmit = (event) => {
        event.preventDefault();
        let pacientex = {
            obra_social: this.state.obra_social,
            pais: this.state.pais,
            provincia: this.state.provincia,
            localidad: this.state.localidad,
            direccion: this.state.direccion,
        }

        let parametros = {
            method: 'PUT',
            body: JSON.stringify(pacientex),
            headers: {
                'Content-Type': 'application/json',
                'token': localStorage.getItem('token')
            }
        }
        const url = `http://localhost:8080/api/paciente/${this.props.params.id_paciente}`

        fetch(url, parametros)
            .then(res => {
                console.log('Response:', res);
                return res.json().then(
                    body => (
                        {
                            status: res.status,
                            ok: res.ok,
                            headers: res.headers,
                            body: body
                        }
                    )
                ).then(
                    result => {debugger
                        if (result.ok) {
                            toast.success(result.body.message, {
                                position: "bottom-center",
                                autoClose: 500,
                                hideProgressBar: false,
                                closeOnClick: true,
                                pauseOnHover: true,
                                draggable: true,
                                progress: undefined,
                                theme: "light",
                            });
                        this.props.navigate("/paciente")
                        } else {
                            toast.error(result.body.message, {
                                position: "bottom-center",
                                autoClose: 500,
                                hideProgressBar: false,
                                closeOnClick: true,
                                pauseOnHover: true,
                                draggable: true,
                                progress: undefined,
                                theme: "light",
                            });
                        }
                    });
            })
            .catch((error) => {
                console.log('Error:', error);
            });
    };

    handleChange = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    };

    render() {
        return (
            <div className='container'>
                <div className='row'>
                    <div className='col'>
                        <h1>{ `Editar Paciente: ${this.props.params.id_paciente}`}</h1>
                        <form onSubmit={this.handleSubmit}>
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingobra_social'
                                    value={this.state.obra_social}
                                    name='obra_social'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingobra_social">obra_social</label>
                            </div>
                            <br />
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingpais'
                                    value={this.state.pais}
                                    name='pais'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingpais">pais</label>
                            </div>
                            <br />
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingprovincia'
                                    value={this.state.provincia}
                                    name='provincia'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingprovincia">provincia</label>
                            </div>
                            <br />
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatinglocalidad'
                                    value={this.state.localidad}
                                    name='localidad'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatinglocalidad">localidad</label>
                            </div>
                            <br />
                            <div className="form-floating">
                                <input
                                    type="text"
                                    className="form-control"
                                    id='floatingdireccion'
                                    value={this.state.direccion}
                                    name='direccion'
                                    onChange={this.handleChange} />
                                <label htmlFor="floatingdireccion">direccion</label>
                            </div>
                            <br />
                            <input
                                className='btn btn-primary'
                                type='submit'
                                value='Guardar'
                            />
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}

export default PacienteEdit


export function PacienteEdit() {
    const p = useParams();
    const navigate = useNavigate();
    return (
        <>
            <PacienteE navigate={navigate} params={p} />
        </>
    );
}