import React, { Component } from 'react';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast';
import { Button } from 'primereact/button';

class BasicDemo extends Component {
    constructor(props) {
        super(props);
        this.toast = React.createRef();
    }

    accept = () => {
        this.toast.current.show({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted', life: 3000 });
    }

    reject = () => {
        this.toast.current.show({ severity: 'warn', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
    }

    confirm1 = () => {
        confirmDialog({
            message: 'Are you sure you want to proceed?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            accept: this.accept,
            reject: this.reject
        });
    };

    confirm2 = () => {
        confirmDialog({
            message: 'Do you want to delete this record?',
            header: 'Delete Confirmation',
            icon: 'pi pi-info-circle',
            acceptClassName: 'p-button-danger',
            accept: this.accept,
            reject: this.reject
        });
    };

    render() {
        return (
            <>
                <Toast ref={this.toast} />
                <ConfirmDialog />
                <div className="card flex flex-wrap gap-2 justify-content-center">
                    <Button onClick={this.confirm1} icon="pi pi-check" label="Confirm"></Button>
                    <Button onClick={this.confirm2} icon="pi pi-times" label="Delete"></Button>
                </div>
            </>
        );
    }
}

export default BasicDemo;